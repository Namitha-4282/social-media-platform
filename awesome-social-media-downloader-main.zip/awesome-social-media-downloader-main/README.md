<div align="center">
  <image src="https://telegraph-image.pages.dev/file/8ac10bda46c21942a3550.png"></image>
</div>
<h1 align="center">awesome-social-media-downloader </h1>
<div align="center">

![GitHub stars](https://img.shields.io/github/stars/DangJin/awesome-social-media-downloader?style=flat&logo=github)
![License](https://img.shields.io/github/license/DangJin/awesome-social-media-downloader?style=flat)
[![X ID](https://img.shields.io/badge/X-@JinsFavorites-1DA1F2?logo=twitter&style=flat)](https://twitter.com/JinsFavorites)

</div>
<p align="center">收录了一些能够免费下载油管、B 站、抖音等平台视频的下载工具。</br>Some download tools that can freely download videos from platforms such as YouTube, Bilibili, Douyin, etc. have been included.  </p>


## 🌟 最受欢迎的
|![lux](https://socialify.git.ci/iawia002/lux/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/iawia002/lux?label=Star)</br>[lux](https://github.com/iawia002/lux)|![Hitomi-Downloader](https://socialify.git.ci/KurtBestor/Hitomi-Downloader/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/KurtBestor/Hitomi-Downloader?label=Star)</br>[Hitomi](https://github.com/KurtBestor/Hitomi-Downloader)|
| :---:         |     :---:      |
|![downkyi](https://socialify.git.ci/leiurayer/downkyi/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/leiurayer/downkyi?label=Star)</br>[downkyi](https://github.com/leiurayer/downkyi)|![gopeed](https://socialify.git.ci/GopeedLab/gopeed/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/GopeedLab/gopeed?label=Star)</br>[gopeed](https://github.com/KurtBestor/GopeedLab/gopeed)|
|![N_m3u8DL-CLI](https://socialify.git.ci/nilaoda/N_m3u8DL-CLI/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/nilaoda/N_m3u8DL-CLI?label=Star)</br>[N_m3u8DL-CLI](https://github.com/KurtBestor/nilaoda/N_m3u8DL-CLI)|![cobalt](https://socialify.git.ci/imputnet/cobalt/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/imputnet/cobalt?label=Star)</br>[cobalt](https://github.com/imputnet/cobalt)|
|![BBDown](https://socialify.git.ci/nilaoda/BBDown/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/nilaoda/BBDown?label=Star)</br>[BBDown](https://github.com/nilaoda/BBDown)|![YoutubeDownloader](https://socialify.git.ci/Tyrrrz/YoutubeDownloader/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/Tyrrrz/YoutubeDownloader?label=Star)</br>[YoutubeDownloader](https://github.com/Tyrrrz/YoutubeDownloader)|
|![wechatVideoDownload](https://socialify.git.ci/qiye45/wechatVideoDownload/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/qiye45/wechatVideoDownload?label=Star)</br>[wechatVideoDownload](https://github.com/qiye45/wechatVideoDownload)||


## 🌟 其他辅助工具
|![video-analyse](https://socialify.git.ci/ta867070117/video-analyse/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/ta867070117/video-analyse?label=Star)</br>[video-analyse](https://github.com/ta867070117/video-analyse)|
| :---:         |  
|![small-video-record](https://socialify.git.ci/mabeijianxi/small-video-record/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Light)![img](https://img.shields.io/github/stars/mabeijianxi/small-video-record?label=Star)</br>[small-video-record](https://github.com/mabeijianxi/small-video-record)|

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=DangJin/awesome-social-media-downloader&type=Date)](https://star-history.com/#DangJin/awesome-social-media-downloader&Date)
